package org.grupo3.proyectofaltasapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFaltasApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
