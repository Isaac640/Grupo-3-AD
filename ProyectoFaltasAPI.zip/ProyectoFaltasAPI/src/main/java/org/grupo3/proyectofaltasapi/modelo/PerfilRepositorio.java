package org.grupo3.proyectofaltasapi.modelo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PerfilRepositorio extends JpaRepository<Perfil, Integer> {

}
