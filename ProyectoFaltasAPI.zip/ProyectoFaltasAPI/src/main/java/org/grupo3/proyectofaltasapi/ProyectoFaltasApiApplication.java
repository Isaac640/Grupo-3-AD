package org.grupo3.proyectofaltasapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFaltasApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFaltasApiApplication.class, args);
	}

}
