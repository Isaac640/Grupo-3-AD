package org.grupo3.proyectofaltasapi.modelo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BajaPermisoRepositorio extends JpaRepository<BajaPermiso, Integer> {

}
