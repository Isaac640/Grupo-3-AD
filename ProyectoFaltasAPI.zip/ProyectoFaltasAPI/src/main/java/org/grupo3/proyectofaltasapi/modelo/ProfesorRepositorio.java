package org.grupo3.proyectofaltasapi.modelo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepositorio extends JpaRepository<Profesor, Integer> {

}
